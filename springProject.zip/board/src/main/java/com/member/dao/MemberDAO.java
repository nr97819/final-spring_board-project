package com.member.dao;

import com.member.domain.MemberVO;

public interface MemberDAO {
	
	// --- 사용자 관리 ---
	
	// 회원가입
	public void register(MemberVO vo) throws Exception;
	
	// 로그인
	public MemberVO login(MemberVO vo) throws Exception;
	
	// 회원탈퇴
	public void withdrawl (MemberVO vo) throws Exception;
}
