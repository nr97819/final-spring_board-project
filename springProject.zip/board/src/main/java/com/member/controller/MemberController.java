package com.member.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.member.domain.MemberVO;
import com.member.service.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@Inject
	MemberService service;

	// 회원가입 (GET)
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public void getRegister() throws Exception{
		
		logger.info("get register");
	}
	
	// 회원가입 (POST)
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String postRegister(MemberVO vo) throws Exception{
	// register.jsp에서 입력한 vo정보들을 받아온다.
		
		logger.info("post register");
		
		service.register(vo);

		return "redirect:/";
	}
	
	// 로그인
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(MemberVO vo, HttpServletRequest req, RedirectAttributes rttr) throws Exception{
		// 로그인 실패시, 경고메세지를 출력하기 위한 객체로 RedirectAttributes의 인스턴스 rttr을 매개변수에 작성 
		
		logger.info("post login");
		
		HttpSession session = req.getSession();
		
		/* view에서 사용자가 입력한 vo 형식의 데이터들을
		     service -> DAO -> DB에 전달 및 비교하고 로그인 가능 여부를 파악해서 가져온다. */
		MemberVO login = service.login(vo, req, rttr);
		
		/* 로그인이 실패하면 어떠한 값도 넘어오지 않으니 null,
			성공하면 mapper에 있는 query문에 대한 결과가 넘어오게 됩니다. */
		
		if(login == null) {
			session.setAttribute("member", null);
			rttr.addFlashAttribute("msg", false);
			// 로그인이 실패한 경우, rttr 객체에 ("msg", false) 속성 추가 
			
			/*
			  조건문에 의해 login이 값이 null이라면, 
			msg라는 정보에 false라는 값이 들어가서 전송됩니다. 
			  이 값은 다른 페이지로 이동하거나 새로고침을 하면 없어지는 
			일회용값이다. 
			
			RedirectAttributes가 제공하는 메소드 addFlashAttribute() 는 
			리다이렉트 직전 플래시에 저장하는 메소드라서, 리다이렉트 이후에는 소멸하기 때문이다.
			*/
			
			// header가 아닌 세션을 통해 전달하므로 뒤에 파라미터가 안 보인다. (하지만 GET 방식,,?)
		}

		// 로그인에 성공한 경우 값이 넘어오면, session에 담습니다.
		else
			session.setAttribute("member", login);
		
		return "redirect:/";
	}
	
	// 로그아웃
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) throws Exception{
		logger.info("get logout");
		
		session.invalidate(); // 세션값 초기화 (로그인에 대한 세션 정보를 없애서 로그아웃시킨다.)
		
		return "redirect:/"; // 홈으로 돌려보낸다.
	}
	
	// 회원탈퇴 (GET)
	@RequestMapping(value = "/withdrawl", method = RequestMethod.GET)
	public void getWithdrawl(MemberVO vo) throws Exception{
		logger.info("get withdrawl");
		
		// 처리
		service.withdrawl(vo);
	}
	
	// 회원탈퇴 (POST)
		@RequestMapping(value = "/withdrawl", method = RequestMethod.POST)
		public String postWithdrawl(HttpSession session, MemberVO vo, RedirectAttributes rttr) throws Exception{
			logger.info("get withdrawl");
			
			MemberVO member = (MemberVO)session.getAttribute("member");
			
			String realPass = member.getUserPass();
			String nowPass = vo.getUserPass();
			
			if(!(realPass.equals(nowPass))) {
				rttr.addFlashAttribute("msg", false);
				return "redirect:/member/withdrawl";
			}
			
			// 처리
			service.withdrawl(vo);
			
			return "redirect:/";
		}
}
