package com.board.domain;

import java.util.Date;

/*
create table myReply (
    bno       int            not null,
    rno       int            auto_increment,
    content   varchar(500)    not null,
    writer    varchar(30)      not null,
    regDate   timestamp      default now(),
    primary key(rno),
    foreign key (bno) references tbl_board (bno)
);
*/
public class ReplyVO {
	private int bno;
	private int rno;
	private String content;
	private String writer;
	private Date regDate;
	
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
}
